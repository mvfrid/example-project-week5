import React from 'react';

import Header from 'components/Header';
import NewsList from 'components/NewsList';
import data from './data.json';

export const App = () => {
	return (
		<section>
			<Header title = 'Students seem to like React'/>
			<NewsList articlesList={data} />
		</section>
	);
};
